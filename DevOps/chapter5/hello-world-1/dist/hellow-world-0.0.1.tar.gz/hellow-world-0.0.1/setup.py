from setuptools import setup, find_packages

setup(
    name="hellow-world",
    version="0.0.1",
    author="Example",
    url="example.com",
    description="A hello-world exapmle package",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operation System :: OS Idependent"
    ],
)